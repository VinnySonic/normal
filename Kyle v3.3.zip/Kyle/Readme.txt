This is Joker, thank you for downloading my Cartman mod
Here I'll show you how to install the mod

You need CTGP or Riivolution
I recommend CTGP's My Stuff folder to add this mod

Copy the .szs file from here to the My Stuff folder on CTGP.

In every vehicle file, there are alternate colors
To change to the alternate colors, go into BrawlCrate and change the body material name from "Cartman_body" to "Cartman_body_(color)" being red, blue, green or yellow

For the Award ceremony model, go into your award.szs file and replace the blg.brres model with the one in the Award folder.

In the Driver folder, there's the model for Kyle on the character select, go into your driver.szs file and replace the blg.brres file with the one in the Driver folder.

For the voice clips, take the BRWSD files of their respective index number and replace them over the ones in your revo_kart.brsar file.
For the ones in the [637] subfolder, you need to go to 637 in the index and replace the respective voices with the ones in the folder.
I don't bother with the NPC voices so if you want to replace them be my guest.

For the icons, take the one named 32x32 and place that over the image on game_image->timg-> st_baby_luigi_32x32.tpl, this is used for the minimap icon.
For the 64x64, you can place this on many icons, including the ones for MenuSingle, MenuMulti, the image on tt_baby_luigi_64x64.tpl on Race.szs, etc.

I have also included Kyle's kart from South Park Rally over the Mini Beast with an allkart file.

Credit goes to Matt Stone and Trey Parker for creating the character, Iguana Entertainment for creating the model, and Tantalus for creating the kart from Rally.