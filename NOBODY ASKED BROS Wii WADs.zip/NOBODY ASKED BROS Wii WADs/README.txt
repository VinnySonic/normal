Note: Both of the WADs don't boot to any app / game. 
I'm not resposibliable for any damage or bricks to your Wii Console, when installing the WADs incorrectly.

DIFFERENCES on Contendo & Nintendo-Fan versions!
Contendo version: New Mario Voice (sounds kinda more realistic than Nintendo-Fan version))
Nintendo-Fan version: Includes OG Mario Voice from this video:
https://youtu.be/6cDEW6px5PM

--------------------
You can see both of differences of what they sound like here:
https://youtu.be/81jc4X2kLR8

I hope you enjoy these WADs. Thanks for downloading!
